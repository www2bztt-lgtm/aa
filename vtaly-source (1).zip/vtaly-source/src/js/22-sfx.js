/**
 * 22-sfx.js - synthesized sound effects (Web Audio, no audio files): thunder, bite, bat flutter.
 * Reacts to the `vtstrike`, `vtbite` and `vtstormstart` events and to the gate click.
 * Honors VT.muted (the M key / mute button).
 */
(function () {
  var ac = null;
  var master = null;
  var noiseBuf = null;

  function ensure() {
    if (ac) {
      if (ac.state === 'suspended') ac.resume();
      return true;
    }
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return false;
    try {
      ac = new AC();
      master = ac.createGain();
      master.gain.value = 0.35;
      master.connect(ac.destination);
      noiseBuf = ac.createBuffer(1, ac.sampleRate * 2, ac.sampleRate);
      var data = noiseBuf.getChannelData(0);
      for (var i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    } catch (e) {
      ac = null;
      return false;
    }
    return true;
  }

  function ok() { return ensure() && !VT.muted; }

  function noise() {
    var src = ac.createBufferSource();
    src.buffer = noiseBuf;
    src.loop = true;
    return src;
  }

  function filter(type, freq, q) {
    var f = ac.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    if (q) f.Q.value = q;
    return f;
  }

  // Exponential attack/decay envelope on a gain node.
  function env(g, t, attack, peak, decay) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + attack + decay);
  }

  function thunder() {
    if (!ok()) return;
    var t = ac.currentTime;
    var rumble = noise();
    var low = filter('lowpass', 900);
    var g = ac.createGain();
    low.frequency.setValueAtTime(900, t + 0.1);
    low.frequency.exponentialRampToValueAtTime(90, t + 1.9);
    rumble.connect(low);
    low.connect(g);
    g.connect(master);
    env(g, t + 0.1, 0.04, 0.9, 1.9);
    rumble.start(t);
    rumble.stop(t + 2.2);

    var crack = noise();
    var hp = filter('highpass', 2500);
    var cg = ac.createGain();
    crack.connect(hp);
    hp.connect(cg);
    cg.connect(master);
    env(cg, t, 0.005, 0.5, 0.12);
    crack.start(t);
    crack.stop(t + 0.2);
  }

  function bite() {
    if (!ok()) return;
    var t = ac.currentTime;
    var osc = ac.createOscillator();
    var og = ac.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(140, t);
    osc.frequency.exponentialRampToValueAtTime(38, t + 0.35);
    osc.connect(og);
    og.connect(master);
    env(og, t, 0.005, 1, 0.4);
    osc.start(t);
    osc.stop(t + 0.5);

    var snap = noise();
    var bp = filter('bandpass', 1800, 0.9);
    var ng = ac.createGain();
    snap.connect(bp);
    bp.connect(ng);
    ng.connect(master);
    env(ng, t, 0.003, 0.6, 0.14);
    snap.start(t);
    snap.stop(t + 0.2);
  }

  function flutter(seconds) {
    if (!ok()) return;
    var t = ac.currentTime;
    var src = noise();
    var bp = filter('bandpass', 2200, 0.7);
    var am = ac.createGain();
    var swell = ac.createGain();
    var lfo = ac.createOscillator();
    var depth = ac.createGain();
    am.gain.value = 0.5;
    lfo.frequency.value = 14;
    depth.gain.value = 0.5;
    lfo.connect(depth);
    depth.connect(am.gain);
    src.connect(bp);
    bp.connect(am);
    am.connect(swell);
    swell.connect(master);
    swell.gain.setValueAtTime(0.0001, t);
    swell.gain.exponentialRampToValueAtTime(0.5, t + seconds * 0.35);
    swell.gain.exponentialRampToValueAtTime(0.0001, t + seconds);
    src.start(t);
    lfo.start(t);
    src.stop(t + seconds + 0.1);
    lfo.stop(t + seconds + 0.1);
  }

  function riser() {
    if (!ok()) return;
    var t = ac.currentTime;
    var src = noise();
    var bp = filter('bandpass', 300, 1.2);
    var g = ac.createGain();
    bp.frequency.setValueAtTime(300, t);
    bp.frequency.exponentialRampToValueAtTime(6000, t + 1.1);
    src.connect(bp);
    bp.connect(g);
    g.connect(master);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.7, t + 1.05);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.25);
    src.start(t);
    src.stop(t + 1.3);

    var osc = ac.createOscillator();
    var og = ac.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(90, t + 1.0);
    osc.frequency.exponentialRampToValueAtTime(32, t + 1.9);
    osc.connect(og);
    og.connect(master);
    env(og, t + 1.0, 0.01, 1, 0.9);
    osc.start(t + 1.0);
    osc.stop(t + 2.0);
  }

  document.getElementById('gate').addEventListener('click', function () {
    if (ensure()) flutter(2.6);
  });
  document.addEventListener('vtstrike', thunder);
  document.addEventListener('vtbite', bite);
  document.addEventListener('vttitle', riser);
  document.addEventListener('vtstormstart', function () { flutter(3.2); });
})();
