/**
 * 26-ae-title-sequence.js - cinematic title card after the gate opens: letterbox bars slide in,
 * the name tracks in letter by letter with blur, an anamorphic streak sweeps across, then it all wipes out.
 * Fires `vttitle` at the start (riser sound) and `vttitlehit` when the letters land (flare, sparks).
 */
(function () {
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var word = document.getElementById('nm').getAttribute('data-t') || 'vtaly';

  function play() {
    var el = document.createElement('div');
    el.className = 'tc on';
    el.setAttribute('aria-hidden', 'true');
    el.innerHTML =
      '<i class="tc__bar tc__bar--t"></i><i class="tc__bar tc__bar--b"></i>' +
      '<div class="tc__center"><div class="tc__word"></div><div class="tc__sub">promo \u00b7 ae \u00b7 2026</div><i class="tc__streak"></i></div>';
    var letters = el.querySelector('.tc__word');
    word.split('').forEach(function (ch, i) {
      var s = document.createElement('span');
      s.textContent = ch;
      s.style.setProperty('--i', i);
      letters.appendChild(s);
    });
    document.body.appendChild(el);
    document.dispatchEvent(new Event('vttitle'));
    VT.titleBusy = true;
    setTimeout(function () { VT.titleBusy = false; }, 3500);
    setTimeout(function () { document.dispatchEvent(new Event('vttitlehit')); }, 1000);
    setTimeout(function () { el.remove(); }, 3400);
  }

  document.addEventListener('vtopen', function () { setTimeout(play, 1200); });
  document.addEventListener('vttitleplay', play);
})();
