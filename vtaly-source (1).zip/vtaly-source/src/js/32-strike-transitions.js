/**
 * 32-strike-transitions.js - every lightning strike plays a different page transition.
 * Eight refined transitions are shuffled in a "bag": none repeats until all have played, never twice in a row,
 * and the wipe picks a random direction each time. All share one timing/easing language (see the CSS).
 * The palette command "Play a page transition" (`vttransition`) previews the next one.
 * This file only toggles html.tx-<id> and creates the overlay panels; the motion lives in 16-strike-transitions.css.
 */
(function () {
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var root = document.documentElement;
  var gate = document.getElementById('gate');
  var TRANSITIONS = [
    { id: 'turny', ms: 1100, aberrate: true },
    { id: 'turnx', ms: 1100, aberrate: true },
    { id: 'push', ms: 1000 },
    { id: 'wipe', ms: 1100 },
    { id: 'split', ms: 1200 },
    { id: 'blinds', ms: 1200 },
    { id: 'iris', ms: 1300 },
    { id: 'flash', ms: 900 },
  ];
  var WIPE_DIRECTIONS = [
    { sx: '-100%', sy: '0', ex: '100%', ey: '0' },
    { sx: '100%', sy: '0', ex: '-100%', ey: '0' },
    { sx: '0', sy: '-100%', ex: '0', ey: '100%' },
    { sx: '0', sy: '100%', ex: '0', ey: '-100%' },
  ];
  var bag = [];
  var lastId = '';
  var running = false;

  function shuffle(list) {
    for (var i = list.length - 1; i > 0; i--) {
      var j = (Math.random() * (i + 1)) | 0;
      var t = list[i];
      list[i] = list[j];
      list[j] = t;
    }
    return list;
  }

  function next() {
    if (!bag.length) {
      bag = shuffle(TRANSITIONS.slice());
      if (bag[0].id === lastId) bag.push(bag.shift());
    }
    return bag.shift();
  }

  function el(className, html) {
    var node = document.createElement('div');
    node.className = className;
    if (html) node.innerHTML = html;
    return node;
  }

  function overlay(t, x, y) {
    var node = null;
    var i;
    if (t.id === 'wipe') {
      var d = WIPE_DIRECTIONS[(Math.random() * WIPE_DIRECTIONS.length) | 0];
      node = el('tx-wipe', '<i></i>');
      node.style.setProperty('--sx', d.sx);
      node.style.setProperty('--sy', d.sy);
      node.style.setProperty('--ex', d.ex);
      node.style.setProperty('--ey', d.ey);
    } else if (t.id === 'split') {
      node = el('tx-split', '<i></i><i></i>');
    } else if (t.id === 'blinds') {
      node = el('tx-blinds');
      for (i = 0; i < 6; i++) {
        var bar = document.createElement('i');
        bar.style.setProperty('--i', i);
        node.appendChild(bar);
      }
    } else if (t.id === 'iris') {
      node = el('tx-iris');
      node.style.setProperty('--x', x + 'px');
      node.style.setProperty('--y', y + 'px');
    } else if (t.id === 'flash') {
      node = el('tx-flash');
      node.style.setProperty('--x', x + 'px');
      node.style.setProperty('--y', y + 'px');
    }
    if (node) document.body.appendChild(node);
    return node;
  }

  function play(x, y) {
    if (running || document.body.classList.contains('pre-open') || !gate.classList.contains('hide')) return;
    var t = next();
    running = true;
    lastId = t.id;
    root.classList.add('tx-' + t.id);
    var node = overlay(t, x, y);
    if (t.aberrate && VT.aberrate) VT.aberrate(400, 2);
    setTimeout(function () {
      root.classList.remove('tx-' + t.id);
      if (node) node.remove();
      running = false;
    }, t.ms + 60);
  }

  document.addEventListener('vtstrike', function (e) {
    if (VT.titleBusy) return; // let the title card play undisturbed
    setTimeout(function () { play(e.detail.x, e.detail.y); }, 120);
  });
  document.addEventListener('vttransition', function () {
    play(window.innerWidth / 2, window.innerHeight / 2);
  });
})();
