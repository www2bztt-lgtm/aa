/**
 * 30-pet-bat.js - a small bat that follows the cursor with a lag, and circles it when you stop moving.
 * Toggle with the palette (`vtpet`). Hidden on touch devices and for reduced motion.
 */
(function () {
  if (window.matchMedia && (window.matchMedia('(prefers-reduced-motion: reduce)').matches || window.matchMedia('(hover: none)').matches)) return;
  var gate = document.getElementById('gate');
  var el = document.createElement('i');
  el.className = 'pet';
  el.setAttribute('aria-hidden', 'true');
  document.body.appendChild(el);

  var x = -60;
  var y = -60;
  var px = x;
  var tx = window.innerWidth / 2;
  var ty = window.innerHeight / 2;
  var angle = 0;
  var flip = 1;
  var seen = false;
  var enabled = true;
  var lastMove = 0;
  var last = performance.now();

  window.addEventListener('pointermove', function (e) {
    tx = e.clientX;
    ty = e.clientY;
    lastMove = performance.now();
    if (!seen) { seen = true; x = tx; y = ty; px = x; }
  }, { passive: true });

  document.addEventListener('vtpet', function () {
    enabled = !enabled;
    VT.toast('Pet bat ' + (enabled ? 'on' : 'off'));
  });

  (function loop(now) {
    var dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    var visible = enabled && seen && gate.classList.contains('hide');
    el.classList.toggle('on', visible);
    if (visible) {
      var goalX;
      var goalY;
      if (now - lastMove > 1800) {
        angle += dt * 2.4;
        goalX = tx + Math.cos(angle) * 60;
        goalY = ty + Math.sin(angle) * 34 - 10;
      } else {
        goalX = tx + 34;
        goalY = ty - 26 + Math.sin(now / 220) * 5;
      }
      var k = 1 - Math.pow(0.0008, dt);
      px = x;
      x += (goalX - x) * k;
      y += (goalY - y) * k;
      var vx = x - px;
      if (vx < -0.3) flip = -1;
      else if (vx > 0.3) flip = 1;
      var tilt = Math.max(-25, Math.min(25, vx * 0.6));
      el.style.transform = 'translate(' + (x - 14).toFixed(1) + 'px,' + (y - 11).toFixed(1) + 'px) rotate(' + tilt.toFixed(1) + 'deg) scaleX(' + flip + ')';
    }
    requestAnimationFrame(loop);
  })(last);
})();
