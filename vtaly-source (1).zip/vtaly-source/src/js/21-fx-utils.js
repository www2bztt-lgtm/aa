/**
 * 21-fx-utils.js - small helpers shared by the effects: VT.drawBat and VT.toast.
 */
VT.drawBat = function (ctx, x, y, s, rot, fl) {
  // Top-down bat, head pointing up before rotation. Caller sets fillStyle/strokeStyle.
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.beginPath();
  ctx.moveTo(-1, 0);
  ctx.lineTo(-0.5 * s, -0.35 * s - 0.35 * s * fl);
  ctx.lineTo(-1.25 * s, -0.7 * s * fl);
  ctx.lineTo(-1 * s, -0.7 * s * fl + 0.35 * s);
  ctx.lineTo(-0.75 * s, 0.05 * s);
  ctx.lineTo(-0.5 * s, 0.35 * s);
  ctx.lineTo(-0.2 * s, 0.1 * s);
  ctx.lineTo(0, 0.4 * s);
  ctx.lineTo(0.2 * s, 0.1 * s);
  ctx.lineTo(0.5 * s, 0.35 * s);
  ctx.lineTo(0.75 * s, 0.05 * s);
  ctx.lineTo(1 * s, -0.7 * s * fl + 0.35 * s);
  ctx.lineTo(1.25 * s, -0.7 * s * fl);
  ctx.lineTo(0.5 * s, -0.35 * s - 0.35 * s * fl);
  ctx.lineTo(1, 0);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(0, 0, 0.17 * s, 0.4 * s, 0, 0, 6.283);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(-0.15 * s, -0.3 * s);
  ctx.lineTo(-0.2 * s, -0.6 * s);
  ctx.lineTo(-0.02 * s, -0.35 * s);
  ctx.moveTo(0.15 * s, -0.3 * s);
  ctx.lineTo(0.2 * s, -0.6 * s);
  ctx.lineTo(0.02 * s, -0.35 * s);
  ctx.fill();
  ctx.restore();
};

VT.toast = function (message) {
  var el = document.createElement('div');
  el.className = 'toast';
  el.setAttribute('role', 'status');
  el.textContent = message;
  document.body.appendChild(el);
  requestAnimationFrame(function () { el.classList.add('on'); });
  setTimeout(function () {
    el.classList.remove('on');
    setTimeout(function () { el.remove(); }, 400);
  }, 2200);
};
