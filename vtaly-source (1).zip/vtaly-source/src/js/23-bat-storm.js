/**
 * 23-bat-storm.js - a full-screen bat storm. Trigger: S key, the command palette (`vtstorm` event),
 * or typing the secret word "dracula".
 */
(function () {
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var gate = document.getElementById('gate');
  var running = false;

  function storm() {
    if (running || reduce || !gate.classList.contains('hide')) return;
    running = true;
    document.dispatchEvent(new Event('vtstormstart'));

    var W = window.innerWidth;
    var H = window.innerHeight;
    var dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    var canvas = document.createElement('canvas');
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    canvas.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:15';
    document.body.appendChild(canvas);
    var ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = '#050005';
    ctx.strokeStyle = 'rgba(255,42,42,.65)';
    ctx.lineWidth = 1;

    var dir = Math.random() < 0.5 ? 1 : -1;
    var rot = dir > 0 ? Math.PI / 2 : -Math.PI / 2;
    var bats = [];
    for (var i = 0; i < 150; i++) {
      bats.push({
        x: (dir > 0 ? -80 : W + 80) - dir * Math.random() * W * 0.7,
        y: Math.random() * H,
        v: dir * (300 + Math.random() * 450),
        amp: 15 + Math.random() * 50,
        wob: Math.random() * 6.283,
        flap: 12 + Math.random() * 10,
        phase: Math.random() * 6.283,
        size: 5 + Math.random() * 13,
      });
    }

    var start = null;
    var last = 0;
    function frame(ts) {
      if (start === null) { start = ts; last = ts; }
      var dt = Math.min(0.05, (ts - last) / 1000);
      var t = (ts - start) / 1000;
      last = ts;
      ctx.clearRect(0, 0, W, H);
      for (var i = 0; i < bats.length; i++) {
        var b = bats[i];
        b.x += b.v * dt;
        if (b.x < -100 || b.x > W + 100) continue;
        VT.drawBat(ctx, b.x, b.y + Math.sin(t * 2 + b.wob) * b.amp, b.size, rot, Math.sin(t * b.flap + b.phase));
      }
      if (t < 4.2) {
        requestAnimationFrame(frame);
      } else {
        canvas.remove();
        running = false;
      }
    }
    requestAnimationFrame(frame);
  }

  function typing(el) {
    return el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable);
  }

  var typed = '';
  document.addEventListener('vtstorm', storm);
  window.addEventListener('keydown', function (e) {
    if (e.ctrlKey || e.metaKey || e.altKey || typing(e.target) || !gate.classList.contains('hide')) return;
    if (e.key.toLowerCase() === 's') storm();
    if (e.key.length === 1) {
      typed = (typed + e.key.toLowerCase()).slice(-12);
      if (typed.slice(-7) === 'dracula') {
        typed = '';
        VT.toast('welcome to the night');
        storm();
      }
    }
  });
})();
