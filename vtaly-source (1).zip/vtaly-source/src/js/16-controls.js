/**
 * 16-controls.js - Seek bar, mute, keyboard shortcuts, cursor parallax variables, local clock.
 */
(function(){
  var au=document.getElementById("au"),pl=document.querySelector(".player"),bar=pl.querySelector(".bar"),tm=document.getElementById("tm"),mu=document.getElementById("mu"),root=document.documentElement,gate=document.getElementById("gate"),keys=document.getElementById("keys"),clk=document.getElementById("clk");
  function fmt(s){s=Math.max(0,Math.floor(s||0));return Math.floor(s/60)+":"+("0"+(s%60)).slice(-2);}
  function upd(){tm.textContent=fmt(au.currentTime)+" / "+fmt(au.duration);}
  au.addEventListener("timeupdate",upd);au.addEventListener("loadedmetadata",upd);
  bar.addEventListener("click",function(e){var r=bar.getBoundingClientRect();if(au.duration)au.currentTime=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width))*au.duration;});
  VT.muted=false;
  function setMute(m){VT.muted=m;if(VT.gain){VT.gain.gain.value=m?0:1;}else{au.muted=m;}mu.textContent=m?"\u{1F507}":"\u{1F50A}";}
  mu.addEventListener("click",function(){setMute(!VT.muted);});
  window.addEventListener("pointermove",function(e){
    root.style.setProperty("--mx",((e.clientX/window.innerWidth-.5)*2).toFixed(3));
    root.style.setProperty("--my",((e.clientY/window.innerHeight-.5)*2).toFixed(3));
  },{passive:true});
  window.addEventListener("keydown",function(e){
    if(!gate.classList.contains("hide")||e.ctrlKey||e.metaKey||e.altKey)return;
    var k=e.key.toLowerCase();
    if(k==="b")document.querySelector(".pfp").click();
    else if(k==="p")document.querySelector(".bio").click();
    else if(k==="m")mu.click();
  });
  document.addEventListener("vtopen",function(){keys.classList.add("on");setTimeout(function(){keys.classList.remove("on");},9000);});
  function tick(){clk.textContent=new Date().toLocaleTimeString([],{hour:"numeric",minute:"2-digit"});}
  tick();setInterval(tick,20000);
})();
