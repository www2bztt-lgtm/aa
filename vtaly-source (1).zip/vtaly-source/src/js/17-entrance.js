/**
 * 17-entrance.js - staggered entrance once the gate opens, plus the view-count roll-up.
 */
(function () {
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var body = document.body;
  if (reduce) return;
  body.classList.add('pre-open');

  function countUp(el, to, ms) {
    var start = performance.now();
    function frame(now) {
      var t = Math.min(1, (now - start) / ms);
      el.textContent = Math.round(to * (1 - Math.pow(1 - t, 3)));
      if (t < 1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  document.addEventListener('vtopen', function () {
    body.classList.add('opening');
    body.classList.remove('pre-open');
    setTimeout(function () { body.classList.remove('opening'); }, 2400);
    var v = document.getElementById('v');
    var to = parseInt(v.textContent, 10) || 1;
    countUp(v, to, 1100);
  });
})();
