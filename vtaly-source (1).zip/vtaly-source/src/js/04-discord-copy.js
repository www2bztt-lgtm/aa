/**
 * 04-discord-copy.js - The Discord button copies the username to the clipboard.
 */
(function(){
  var b=document.getElementById("dc"),name="uwantvtaly",orig=b.textContent;
  function done(){b.textContent="Copied! Add me on Discord";setTimeout(function(){b.textContent=orig;},1800);}
  b.addEventListener("click",function(){
    function fallback(){
      var t=document.createElement("textarea");t.value=name;t.style.position="fixed";t.style.opacity="0";
      document.body.appendChild(t);t.select();
      try{document.execCommand("copy");}catch(e){}
      document.body.removeChild(t);done();
    }
    try{
      if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(name).then(done,fallback);}
      else{fallback();}
    }catch(e){fallback();}
  });
})();
