/**
 * 24-command-palette.js - press "/" for a command palette (filter, arrow keys, Enter, Esc).
 * Commands reuse the existing features by clicking their controls or dispatching events.
 */
(function () {
  var gate = document.getElementById('gate');
  var commands = [
    { name: 'Bite the name', key: 'B', run: function () { document.querySelector('.pfp').click(); } },
    { name: 'Paint the bio', key: 'P', run: function () { document.querySelector('.bio').click(); } },
    { name: 'Summon lightning', key: '', run: function () { document.dispatchEvent(new Event('vtsummon')); } },
    { name: 'Play a page transition', key: '', run: function () { document.dispatchEvent(new Event('vttransition')); } },
    { name: 'Bat storm', key: 'S', run: function () { document.dispatchEvent(new Event('vtstorm')); } },
    { name: 'Replay title sequence', key: '', run: function () { document.dispatchEvent(new Event('vttitleplay')); } },
    { name: 'Toggle rain', key: '', run: function () { document.dispatchEvent(new Event('vtrain')); } },
    { name: 'Toggle pet bat', key: '', run: function () { document.dispatchEvent(new Event('vtpet')); } },
    { name: 'Effects quality: high / low', key: 'Q', run: function () { document.dispatchEvent(new Event('vtquality')); } },
    { name: 'Mute / unmute', key: 'M', run: function () { document.getElementById('mu').click(); } },
    { name: 'Copy Discord username', key: '', run: function () { document.getElementById('dc').click(); VT.toast('Discord username copied'); } },
    { name: 'Open NameMC', key: '', run: function () { window.open('https://namemc.com/search?q=heartlwss', '_blank', 'noopener,noreferrer'); } },
    { name: 'Replay intro', key: '', run: function () { window.location.reload(); } },
  ];
  var root = null;
  var input = null;
  var list = null;
  var isOpen = false;
  var shown = commands;
  var selected = 0;
  var previous = null;

  function build() {
    root = document.createElement('div');
    root.className = 'pal';
    root.setAttribute('role', 'dialog');
    root.setAttribute('aria-modal', 'true');
    root.setAttribute('aria-label', 'Command palette');
    root.innerHTML =
      '<div class="pal__box">' +
      '<input class="pal__input" type="text" placeholder="type a command..." aria-label="Command" autocomplete="off" spellcheck="false">' +
      '<ul class="pal__list" role="listbox"></ul></div>';
    document.body.appendChild(root);
    input = root.querySelector('.pal__input');
    list = root.querySelector('.pal__list');

    root.addEventListener('click', function (e) { if (e.target === root) hide(); });
    list.addEventListener('click', function (e) {
      var li = e.target.closest('.pal__item');
      if (li) choose(Number(li.dataset.i));
    });
    input.addEventListener('input', function () {
      var q = input.value.trim().toLowerCase();
      shown = commands.filter(function (c) { return c.name.toLowerCase().indexOf(q) !== -1; });
      selected = 0;
      render();
    });
    input.addEventListener('keydown', function (e) {
      e.stopPropagation(); // keep typed letters from triggering the B / P / M / S shortcuts
      if (e.key === 'Escape') hide();
      else if (e.key === 'Enter') choose(selected);
      else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        if (shown.length) selected = (selected + (e.key === 'ArrowDown' ? 1 : shown.length - 1)) % shown.length;
        render();
      }
    });
  }

  function render() {
    list.innerHTML = '';
    shown.forEach(function (c, i) {
      var li = document.createElement('li');
      li.className = 'pal__item';
      li.dataset.i = i;
      li.setAttribute('role', 'option');
      li.setAttribute('aria-selected', String(i === selected));
      li.innerHTML = '<span></span>' + (c.key ? '<kbd>' + c.key + '</kbd>' : '');
      li.firstChild.textContent = c.name;
      list.appendChild(li);
    });
  }

  function choose(i) {
    var cmd = shown[i];
    if (!cmd) return;
    hide();
    setTimeout(cmd.run, 120);
  }

  function show() {
    if (isOpen || !gate.classList.contains('hide')) return;
    if (!root) build();
    isOpen = true;
    previous = document.activeElement;
    input.value = '';
    shown = commands;
    selected = 0;
    render();
    root.classList.add('on');
    setTimeout(function () { input.focus(); }, 30);
  }

  function hide() {
    if (!isOpen) return;
    isOpen = false;
    root.classList.remove('on');
    if (previous && previous.focus) previous.focus();
  }

  window.addEventListener('keydown', function (e) {
    var t = e.target;
    var typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
    if (e.key === '/' && !isOpen && !typing && !e.ctrlKey && !e.metaKey && !e.altKey) {
      e.preventDefault();
      show();
    } else if (e.key === 'Escape' && isOpen) {
      hide();
    }
  });
})();
