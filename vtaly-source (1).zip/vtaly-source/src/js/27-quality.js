/**
 * 27-quality.js - effects quality. "high" runs everything; "low" turns off the heavy layers
 * (grain, scanlines, light leaks, spotlight, big backdrop, aberration, slices, zoom, spectrum, rain).
 * The choice is saved, Q or the palette toggles it, and a frame-rate governor drops to "low" on slow devices.
 */
(function () {
  var KEY = 'vt-quality';
  var root = document.documentElement;
  var gate = document.getElementById('gate');
  var saved = null;
  try { saved = localStorage.getItem(KEY); } catch (e) {}
  VT.quality = saved === 'low' ? 'low' : 'high';

  function apply(quality, announce) {
    VT.quality = quality;
    root.setAttribute('data-quality', quality);
    try { localStorage.setItem(KEY, quality); } catch (e) {}
    if (announce) VT.toast('Effects quality: ' + quality);
  }
  apply(VT.quality, false);

  document.addEventListener('vtquality', function () { apply(VT.quality === 'high' ? 'low' : 'high', true); });
  window.addEventListener('keydown', function (e) {
    var t = e.target;
    var typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
    if (e.key.toLowerCase() === 'q' && !typing && !e.ctrlKey && !e.metaKey && !e.altKey && gate.classList.contains('hide')) {
      document.dispatchEvent(new Event('vtquality'));
    }
  });

  // Frame-rate governor: three slow 2-second windows in a row (after the intro) switch to "low".
  var armed = false;
  var frames = 0;
  var start = 0;
  var slow = 0;
  function reset() { frames = 0; slow = 0; start = performance.now(); }
  document.addEventListener('vtopen', function () { setTimeout(function () { armed = true; reset(); }, 6500); });
  document.addEventListener('visibilitychange', reset);
  (function loop(now) {
    if (armed && !document.hidden && VT.quality === 'high') {
      frames++;
      if (now - start >= 2000) {
        slow = (frames * 1000) / (now - start) < 38 ? slow + 1 : 0;
        frames = 0;
        start = now;
        if (slow >= 3) {
          apply('low', false);
          VT.toast('Slow device detected: effects set to low (press Q to change)');
        }
      }
    }
    requestAnimationFrame(loop);
  })(0);
})();
