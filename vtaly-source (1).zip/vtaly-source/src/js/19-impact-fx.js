/**
 * 19-impact-fx.js - screen shake and glass cracks on the bite, a light shake on lightning.
 * Listens for the `vtbite` and `vtstrike` events (detail: {x, y} in viewport pixels).
 */
(function () {
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var main = document.querySelector('main');

  function shake(cls) {
    main.classList.remove('shake', 'shake-sm');
    void main.offsetWidth;
    main.classList.add(cls);
    setTimeout(function () { main.classList.remove(cls); }, 500);
  }

  function cracks(x, y) {
    var W = window.innerWidth;
    var H = window.innerHeight;
    var d = '';
    for (var i = 0; i < 11; i++) {
      var a = (i / 11) * 6.283 + Math.random() * 0.4;
      var len = 120 + Math.random() * Math.max(W, H) * 0.35;
      var steps = 5 + ((Math.random() * 4) | 0);
      var cx = x;
      var cy = y;
      d += 'M' + x + ' ' + y;
      for (var s = 1; s <= steps; s++) {
        var aa = a + (Math.random() - 0.5) * 0.5;
        cx += (Math.cos(aa) * len) / steps;
        cy += (Math.sin(aa) * len) / steps;
        d += ' L' + cx.toFixed(1) + ' ' + cy.toFixed(1);
      }
    }
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'cracks');
    svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
    svg.setAttribute('preserveAspectRatio', 'none');
    svg.innerHTML =
      '<g fill="none" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="' + d + '" stroke="rgba(255,40,40,.5)" stroke-width="5"/>' +
      '<path d="' + d + '" stroke="#fff" stroke-width="1.3"/></g>';
    document.body.appendChild(svg);
    setTimeout(function () { svg.remove(); }, 1900);
  }

  document.addEventListener('vtbite', function (e) {
    shake('shake');
    cracks(e.detail.x, e.detail.y);
  });
  document.addEventListener('vtstrike', function () { shake('shake-sm'); });
})();
