/**
 * 29-rain.js - slanted red-tinted rain behind the card. Lightning (`vtstrike`) makes it flash.
 * Toggle with the palette (`vtrain`). Off in "low" quality.
 */
(function () {
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var canvas = document.createElement('canvas');
  canvas.id = 'rain';
  canvas.setAttribute('aria-hidden', 'true');
  canvas.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:-1';
  document.body.appendChild(canvas);
  var g = canvas.getContext('2d');
  var W = 0;
  var H = 0;
  var drops = [];
  var enabled = true;
  var flash = 0;
  var last = performance.now();
  var cleared = true;

  function make(randomY) {
    return { x: Math.random() * (W + 200) - 100, y: randomY ? Math.random() * H : -30, len: 10 + Math.random() * 22, v: 700 + Math.random() * 600, a: 0.15 + Math.random() * 0.25 };
  }

  function size() {
    var dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    drops = [];
    for (var i = 0, n = Math.min(160, Math.round((W * H) / 9000)); i < n; i++) drops.push(make(true));
  }
  size();
  window.addEventListener('resize', size);

  document.addEventListener('vtstrike', function () { flash = 1; });
  document.addEventListener('vtrain', function () {
    enabled = !enabled;
    VT.toast('Rain ' + (enabled ? 'on' : 'off'));
  });

  (function loop(now) {
    var dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    if (!enabled || VT.quality === 'low' || document.body.classList.contains('pre-open')) {
      if (!cleared) { g.clearRect(0, 0, W, H); cleared = true; }
    } else {
      cleared = false;
      g.clearRect(0, 0, W, H);
      g.lineWidth = 1;
      flash *= 0.9;
      for (var i = 0; i < drops.length; i++) {
        var d = drops[i];
        d.y += d.v * dt;
        d.x += d.v * dt * 0.25;
        if (d.y > H + 30) drops[i] = make(false);
        g.strokeStyle = 'rgba(255,130,150,' + Math.min(1, d.a + flash * 0.35) + ')';
        g.beginPath();
        g.moveTo(d.x, d.y);
        g.lineTo(d.x - d.len * 0.25, d.y - d.len);
        g.stroke();
      }
    }
    requestAnimationFrame(loop);
  })(last);
})();
