/**
 * 25-ae-fx.js - After Effects style helpers, all exposed on VT:
 *   VT.flare(x, y, k)        anamorphic lens flare with ghosts
 *   VT.sparks(x, y, n, col)  additive particle burst with trails
 *   VT.aberrate(ms, amp)     RGB-split chromatic aberration pulse on the card
 *   VT.slices(n)             datamosh-style inverted slices
 *   VT.zoom()                radial zoom burst
 *   VT.punch()               camera push-in
 * They fire on the vtbite / vtstrike / vtstormstart / vttitlehit events and on strong beats.
 */
(function () {
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var body = document.body;
  var main = document.querySelector('main');
  var card = document.querySelector('.card');

  var DEFS =
    '<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">' +
    '<filter id="ae-ca" x="-5%" y="-5%" width="110%" height="110%" color-interpolation-filters="sRGB">' +
    '<feColorMatrix in="SourceGraphic" type="matrix" values="1 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0" result="r"/>' +
    '<feOffset id="ae-r" in="r" dx="0" dy="0" result="ro"/>' +
    '<feColorMatrix in="SourceGraphic" type="matrix" values="0 0 0 0 0  0 1 0 0 0  0 0 0 0 0  0 0 0 1 0" result="g"/>' +
    '<feColorMatrix in="SourceGraphic" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 1 0 0  0 0 0 1 0" result="b"/>' +
    '<feOffset id="ae-b" in="b" dx="0" dy="0" result="bo"/>' +
    '<feBlend in="ro" in2="g" mode="screen" result="rg"/>' +
    '<feBlend in="rg" in2="bo" mode="screen"/></filter></svg>';
  body.insertAdjacentHTML('beforeend', DEFS + '<div id="ae-leaks" aria-hidden="true"><i></i><i></i></div><div id="ae-crt" aria-hidden="true"></div>');

  var offR = document.getElementById('ae-r');
  var offB = document.getElementById('ae-b');
  var aberrationFrame = 0;

  VT.aberrate = function (ms, amp) {
    if (VT.quality === 'low') return;
    cancelAnimationFrame(aberrationFrame);
    card.classList.add('ae-ca');
    var t0 = performance.now();
    function step(now) {
      var t = (now - t0) / ms;
      if (t >= 1) {
        card.classList.remove('ae-ca');
        offR.setAttribute('dx', 0);
        offB.setAttribute('dx', 0);
        return;
      }
      var k = Math.pow(1 - t, 2) * amp;
      offR.setAttribute('dx', (-k).toFixed(2));
      offB.setAttribute('dx', k.toFixed(2));
      aberrationFrame = requestAnimationFrame(step);
    }
    aberrationFrame = requestAnimationFrame(step);
  };

  VT.flare = function (x, y, k) {
    k = k || 1;
    var cx = window.innerWidth / 2;
    var cy = window.innerHeight / 2;
    var el = document.createElement('div');
    el.className = 'ae-flare';
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    el.style.setProperty('--k', k);
    var html = '<i class="ae-flare__core"></i><i class="ae-flare__streak"></i>';
    [[0.5, 40, 0], [0.9, 70, 20], [1.4, 28, 330], [1.9, 110, 10]].forEach(function (g) {
      var s = g[1] * k;
      var left = (cx - x) * g[0] - s / 2;
      var top = (cy - y) * g[0] - s / 2;
      html += '<i class="ae-flare__ghost" style="width:' + s + 'px;height:' + s + 'px;left:' + left + 'px;top:' + top +
        'px;border-color:hsla(' + g[2] + ',100%,62%,.55);background:radial-gradient(circle,hsla(' + g[2] + ',100%,60%,.18),transparent 70%)"></i>';
    });
    el.innerHTML = html;
    body.appendChild(el);
    setTimeout(function () { el.remove(); }, 950);
  };

  VT.sparks = function (x, y, n, color) {
    if (VT.quality === 'low') n = Math.ceil(n / 3);
    var W = window.innerWidth;
    var H = window.innerHeight;
    var dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    var c = document.createElement('canvas');
    c.width = W * dpr;
    c.height = H * dpr;
    c.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:19';
    body.appendChild(c);
    var g = c.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.lineCap = 'round';
    var ps = [];
    for (var i = 0; i < n; i++) {
      var a = Math.random() * 6.283;
      var v = 120 + Math.random() * 560;
      ps.push({ x: x, y: y, px: x, py: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 120, life: 0, max: 0.7 + Math.random() * 0.8, w: 1 + Math.random() * 2.2 });
    }
    var last = null;
    var t0 = null;
    function frame(ts) {
      if (last === null) { last = ts; t0 = ts; }
      var dt = Math.min(0.05, (ts - last) / 1000);
      last = ts;
      g.globalCompositeOperation = 'destination-out';
      g.fillStyle = 'rgba(0,0,0,.22)';
      g.fillRect(0, 0, W, H);
      g.globalCompositeOperation = 'lighter';
      g.strokeStyle = color;
      for (var i = 0; i < ps.length; i++) {
        var p = ps[i];
        p.life += dt;
        if (p.life > p.max) continue;
        p.px = p.x;
        p.py = p.y;
        p.vx *= 0.985;
        p.vy = p.vy * 0.985 + 700 * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        g.globalAlpha = 1 - p.life / p.max;
        g.lineWidth = p.w;
        g.beginPath();
        g.moveTo(p.px, p.py);
        g.lineTo(p.x, p.y);
        g.stroke();
      }
      g.globalAlpha = 1;
      if (ts - t0 < 1700) requestAnimationFrame(frame);
      else c.remove();
    }
    requestAnimationFrame(frame);
  };

  VT.slices = function (n) {
    if (VT.quality === 'low') return;
    for (var i = 0; i < n; i++) {
      var s = document.createElement('i');
      s.className = 'ae-slice';
      s.style.top = Math.random() * 90 + '%';
      s.style.height = 10 + Math.random() * 46 + 'px';
      s.style.setProperty('--dx', (Math.random() - 0.5) * 90 + 'px');
      s.style.animationDelay = i * 40 + 'ms';
      body.appendChild(s);
      (function (el) { setTimeout(function () { el.remove(); }, 520); })(s);
    }
  };

  VT.zoom = function () {
    if (VT.quality === 'low') return;
    var z = document.createElement('div');
    z.className = 'ae-zoom';
    body.appendChild(z);
    setTimeout(function () { z.remove(); }, 800);
  };

  VT.punch = function () {
    main.classList.remove('impact');
    void main.offsetWidth;
    main.classList.add('impact');
    setTimeout(function () { main.classList.remove('impact'); }, 700);
  };

  document.addEventListener('vtbite', function (e) {
    var x = e.detail.x;
    var y = e.detail.y;
    VT.flare(x, y, 1.5);
    VT.sparks(x, y, 110, '#ff3a3a');
    VT.sparks(x, y, 50, '#ffe0e0');
    VT.aberrate(500, 5);
    VT.slices(4);
    VT.zoom();
    VT.punch();
  });

  document.addEventListener('vtstrike', function (e) {
    VT.flare(e.detail.x, e.detail.y, 1.1);
    VT.sparks(e.detail.x, e.detail.y, 70, '#ffffff');
    VT.aberrate(320, 3.5);
    VT.slices(3);
  });

  document.addEventListener('vtstormstart', function () {
    VT.zoom();
    VT.aberrate(600, 3);
  });

  document.addEventListener('vttitlehit', function () {
    var x = window.innerWidth / 2;
    var y = window.innerHeight * 0.42;
    VT.flare(x, y, 2);
    VT.sparks(x, y, 80, '#ff5a5a');
    VT.aberrate(450, 4);
    VT.slices(3);
    VT.zoom();
  });

  // Strong bass hits pulse the chromatic aberration.
  var avg = 0;
  var lastBeat = 0;
  (function loop(now) {
    var level = VT.level || 0;
    if (level > 0 && !body.classList.contains('pre-open')) {
      avg += (level - avg) * 0.04;
      if (level > 0.45 && level > avg * 1.35 && now - lastBeat > 550) {
        lastBeat = now;
        VT.aberrate(170, 2.2);
      }
    }
    requestAnimationFrame(loop);
  })(0);
})();
