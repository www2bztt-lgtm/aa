/**
 * 31-spectrum.js - audio spectrum along the bottom of the screen (mirrored bars with falling peak caps),
 * the classic After Effects "Audio Spectrum" look. Reads VT.analyser; off in "low" quality or when paused.
 */
(function () {
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  var au = document.getElementById('au');
  var canvas = document.createElement('canvas');
  canvas.id = 'spectrum';
  canvas.setAttribute('aria-hidden', 'true');
  canvas.style.cssText = 'position:fixed;left:0;bottom:0;width:100%;height:140px;pointer-events:none;z-index:-1;opacity:.85';
  document.body.appendChild(canvas);
  var g = canvas.getContext('2d');
  var BARS = 48;
  var H = 140;
  var W = 0;
  var peaks = [];
  var data = null;
  var drawn = false;
  for (var p = 0; p < BARS; p++) peaks.push(0);

  function size() {
    var dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    W = window.innerWidth;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  size();
  window.addEventListener('resize', size);

  (function loop() {
    var an = VT.analyser;
    var active = an && !au.paused && VT.quality !== 'low' && !document.body.classList.contains('pre-open');
    if (active) {
      if (!data) data = new Uint8Array(an.frequencyBinCount);
      an.getByteFrequencyData(data);
      g.clearRect(0, 0, W, H);
      var bw = W / (BARS * 2);
      var step = Math.max(1, Math.floor((data.length * 0.7) / BARS));
      var grad = g.createLinearGradient(0, H, 0, 0);
      grad.addColorStop(0, 'rgba(255,30,30,.9)');
      grad.addColorStop(1, 'rgba(255,110,170,0)');
      for (var i = 0; i < BARS; i++) {
        var h = Math.pow(data[i * step] / 255, 1.5) * H * 0.95;
        peaks[i] = Math.max(h, peaks[i] - 1.2);
        var right = W / 2 + i * bw;
        var left = W / 2 - (i + 1) * bw;
        g.fillStyle = grad;
        g.fillRect(right + 1, H - h, bw - 2, h);
        g.fillRect(left + 1, H - h, bw - 2, h);
        g.fillStyle = 'rgba(255,220,220,.8)';
        g.fillRect(right + 1, H - peaks[i] - 3, bw - 2, 2);
        g.fillRect(left + 1, H - peaks[i] - 3, bw - 2, 2);
      }
      drawn = true;
    } else if (drawn) {
      g.clearRect(0, 0, W, H);
      drawn = false;
    }
    requestAnimationFrame(loop);
  })();
})();
