/**
 * 28-magnetic-ui.js - badges and buttons lean toward the cursor when it gets close.
 */
(function () {
  if (window.matchMedia && (window.matchMedia('(prefers-reduced-motion: reduce)').matches || window.matchMedia('(hover: none)').matches)) return;
  var els = [].slice.call(document.querySelectorAll('.bdg, .sp, .player button'));
  var RANGE = 70;
  var PULL = 0.3;
  var px = 0;
  var py = 0;
  var queued = false;

  function update() {
    queued = false;
    var rects = els.map(function (el) { return el.getBoundingClientRect(); });
    els.forEach(function (el, i) {
      var r = rects[i];
      var dx = px - (r.left + r.width / 2);
      var dy = py - (r.top + r.height / 2);
      var reach = RANGE + Math.max(r.width, r.height) / 2;
      var d = Math.hypot(dx, dy);
      if (d < reach) {
        var k = 1 - d / reach;
        el.style.translate = (dx * PULL * k).toFixed(1) + 'px ' + (dy * PULL * k).toFixed(1) + 'px';
      } else if (el.style.translate) {
        el.style.translate = '';
      }
    });
  }

  window.addEventListener('pointermove', function (e) {
    px = e.clientX;
    py = e.clientY;
    if (!queued) {
      queued = true;
      requestAnimationFrame(update);
    }
  }, { passive: true });
})();
