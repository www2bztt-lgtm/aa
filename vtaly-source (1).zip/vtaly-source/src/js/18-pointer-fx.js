/**
 * 18-pointer-fx.js - cursor spotlight, the avatar's eyes following the pointer, click bat bursts.
 */
(function () {
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var root = document.documentElement;
  var gate = document.getElementById('gate');
  var pf = document.querySelector('.pfp');
  var eyes = pf.querySelectorAll('.peye, .pup, .eg');
  var px = 0;
  var py = 0;
  var queued = false;

  function update() {
    queued = false;
    root.style.setProperty('--cx', px + 'px');
    root.style.setProperty('--cy', py + 'px');
    var r = pf.getBoundingClientRect();
    var dx = px - (r.left + r.width / 2);
    var dy = py - (r.top + r.height * 0.45);
    var dist = Math.hypot(dx, dy) || 1;
    var m = Math.min(2.4, dist / 80); // SVG units
    var move = ((dx / dist) * m).toFixed(2) + 'px ' + ((dy / dist) * m).toFixed(2) + 'px';
    for (var i = 0; i < eyes.length; i++) eyes[i].style.translate = move;
  }

  window.addEventListener('pointermove', function (e) {
    px = e.clientX;
    py = e.clientY;
    if (!queued) {
      queued = true;
      requestAnimationFrame(update);
    }
  }, { passive: true });

  window.addEventListener('pointerdown', function (e) {
    if (reduce || !gate.classList.contains('hide')) return;
    for (var i = 0; i < 7; i++) {
      var b = document.createElement('i');
      var a = Math.random() * 6.283;
      var d = 50 + Math.random() * 90;
      b.className = 'cb';
      b.style.left = e.clientX + 'px';
      b.style.top = e.clientY + 'px';
      b.style.setProperty('--dx', Math.cos(a) * d + 'px');
      b.style.setProperty('--dy', Math.sin(a) * d - 30 + 'px');
      b.style.setProperty('--r', Math.random() * 80 - 40 + 'deg');
      document.body.appendChild(b);
      (function (el) { setTimeout(function () { el.remove(); }, 950); })(b);
    }
  }, { passive: true });
})();
