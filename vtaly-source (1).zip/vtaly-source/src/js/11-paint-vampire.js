/**
 * 11-paint-vampire.js - A flying vampire paints "dm" and "2026" in the bio badge.
 */
(function(){
  var spr=document.getElementById("pv"),gate=document.getElementById("gate"),pts=document.querySelectorAll(".pt"),bio=document.querySelector(".bio");
  var reduce=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var running=false,sx=1,pc=null,lastDot=0,pi=0,TX=44,TY=32.8;
  var pal=[["#ff9a9a","#ff1a1a"],["#ffe08a","#ffa500"],["#ffb3e6","#ff2fa0"],["#b8f3ff","#1aa6ff"],["#d6b8ff","#7a2bff"]];
  function setP(el,v){el.style.setProperty("--p",v);}
  if(reduce){for(var q=0;q<pts.length;q++)setP(pts[q],1);return;}
  function cr(a,b,c,d,t){var t2=t*t,t3=t2*t;return .5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t2+(-a+3*b-3*c+d)*t3);}
  function spl(P,u){var n=P.length-1,f=u*n,i=Math.min(n-1,Math.floor(f)),t=f-i,a=P[Math.max(0,i-1)],b=P[i],c=P[i+1],d=P[Math.min(n,i+2)];return [cr(a[0],b[0],c[0],d[0],t),cr(a[1],b[1],c[1],d[1],t)];}
  function ease(t){return t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2;}
  function R(i){return pts[i].getBoundingClientRect();}
  function tipC(t){return [t[0]-TX,t[1]-TY];}
  function place(c,force){
    var vx=pc?c[0]-pc[0]:0,vy=pc?c[1]-pc[1]:0;pc=[c[0],c[1]];
    var tsx=force?1:(vx<-.4?-1:(vx>.4?1:(sx>0?1:-1)));sx+=(tsx-sx)*.18;
    var rot=force?0:Math.max(-16,Math.min(16,vy*.9*(sx>0?1:-1)));
    spr.style.transform="translate("+(c[0]-48).toFixed(1)+"px,"+(c[1]-40).toFixed(1)+"px) rotate("+rot.toFixed(1)+"deg) scaleX("+sx.toFixed(2)+")";
  }
  function dot(x,y,col){
    var n=performance.now();if(n-lastDot<45)return;lastDot=n;
    var d=document.createElement("i");d.className="pdot";d.style.left=x+"px";d.style.top=y+"px";d.style.background=col;
    d.style.setProperty("--dx",((Math.random()-.5)*50)+"px");d.style.setProperty("--dy",(10+Math.random()*30)+"px");
    document.body.appendChild(d);setTimeout(function(){d.remove();},800);
  }
  function drips(el){
    for(var k=0;k<5;k++){var d=document.createElement("i");d.className="pd";d.style.left=(8+Math.random()*84)+"%";d.style.animationDelay=(Math.random()*.6)+"s";el.appendChild(d);(function(d){setTimeout(function(){d.remove();},3400);})(d);}
  }
  function run(){
    if(running||!gate.classList.contains("hide"))return;
    running=true;pc=null;sx=1;
    var p=pal[pi++%pal.length];
    for(var q=0;q<pts.length;q++){pts[q].style.setProperty("--pa",p[0]);pts[q].style.setProperty("--pb",p[1]);}
    var W=window.innerWidth,H=window.innerHeight,col=p[1];
    function paintSeg(i,dur){return{d:dur,s:function(){setP(pts[i],0);},
      f:function(u){var r=R(i),x=r.left-4+(r.width+8)*u,y=r.top+r.height*.55+Math.sin(u*20)*r.height*.2;
        setP(pts[i],Math.max(0,Math.min(1,(x-r.left)/r.width)));place(tipC([x,y]),true);dot(x,y,col);},
      e:function(){setP(pts[i],1);drips(pts[i]);}};}
    var segs=[
      {d:4300,f:function(u){var r=R(0),end=tipC([r.left-4,r.top+r.height*.55]);
        var path=[[-100,H*.2],[W*.55,H*.1],[W*.92,H*.42],[W*.6,H*.82],[W*.1,H*.62],[W*.28,H*.24],end];
        place(spl(path,ease(u)),u>.9);}},
      paintSeg(0,900),
      {d:600,f:function(u){var a=R(0),b=R(1),s=tipC([a.right+4,a.top+a.height*.55]),t=tipC([b.left-4,b.top+b.height*.55]);
        place(spl([s,[(s[0]+t[0])/2,Math.min(s[1],t[1])-34],t],ease(u)),true);}},
      paintSeg(1,1200),
      {d:1900,f:function(u){var b=R(1),s=tipC([b.right+4,b.top+b.height*.55]);
        place(spl([s,[s[0]+30,s[1]-50],[W*.75,H*.15],[W+140,-80]],ease(u)),u<.15);}}
    ];
    spr.style.opacity="1";
    var si=0,st=null;
    function frame(ts){
      if(st===null){st=ts;if(segs[si].s)segs[si].s();}
      var sg=segs[si],u=Math.min(1,(ts-st)/sg.d);sg.f(u);
      if(u>=1){if(sg.e)sg.e();si++;st=null;if(si>=segs.length){spr.style.opacity="0";running=false;return;}}
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }
  document.addEventListener("vtopen",function(){setTimeout(run,3200);});
  bio.addEventListener("click",run);
  setInterval(run,45000);
})();
