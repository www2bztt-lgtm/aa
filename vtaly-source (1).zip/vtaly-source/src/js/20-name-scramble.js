/**
 * 20-name-scramble.js - hovering the name scrambles the letters, then resolves them left to right.
 */
(function () {
  var nm = document.getElementById('nm');
  var node = nm.firstChild; // the text node; the <i> children (drips, sparkles) are left alone
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  if (!node || node.nodeType !== 3) return;

  var word = node.nodeValue;
  var letters = 'abcdefghijklmnopqrstuvwxyz';
  var timer = null;
  var busy = false;

  nm.addEventListener('mouseenter', function () {
    if (busy) return;
    busy = true;
    var frame = 0;
    var total = 18;
    timer = setInterval(function () {
      frame++;
      var out = '';
      for (var i = 0; i < word.length; i++) {
        out += frame / total > (i + 1) / (word.length + 1) ? word[i] : letters[(Math.random() * 26) | 0];
      }
      node.nodeValue = out;
      if (frame >= total) {
        clearInterval(timer);
        node.nodeValue = word;
        busy = false;
      }
    }, 40);
  });
})();
