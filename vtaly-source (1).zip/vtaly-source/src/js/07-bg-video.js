/**
 * 07-bg-video.js - Starts the background video (autoplay can wait for a gesture).
 */
(function(){
  var v=document.getElementById("bgv");
  function p(){var r=v.play();if(r&&r.catch)r.catch(function(){});}
  p();
  document.getElementById("gate").addEventListener("click",p);
  window.addEventListener("pointerdown",function(){if(v.paused)p();},{passive:true,once:true});
})();
