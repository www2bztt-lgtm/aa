/**
 * 15-badges.js - Reveals the badge row once the page is open.
 */
(function(){
  var b=document.getElementById("badges");
  document.addEventListener("vtopen",function(){setTimeout(function(){b.classList.add("in");},500);});
  if(window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches)b.classList.add("in");
})();
