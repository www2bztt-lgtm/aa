/**
 * 12-gate-reveal.js - Bat swarm erases the entry cover, then fires the vtopen event.
 */
(function(){
  var gate=document.getElementById("gate"),fired=false;
  var reduce=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  function open(){document.dispatchEvent(new Event("vtopen"));}
  gate.addEventListener("click",function(e){
    if(fired)return;fired=true;
    if(reduce){open();return;}
    var W=window.innerWidth,H=window.innerHeight,dpr=Math.min(window.devicePixelRatio||1,1.5),ox=e.clientX||W/2,oy=e.clientY||H/2;
    function mk(z){var c=document.createElement("canvas");c.width=W*dpr;c.height=H*dpr;c.style.cssText="position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:"+z;document.body.appendChild(c);var x=c.getContext("2d");x.setTransform(dpr,0,0,dpr,0,0);return [c,x];}
    var cv=mk(20),bv=mk(21),cc=cv[1],bc=bv[1];
    cc.fillStyle="#1a0000";cc.fillRect(0,0,W,H);var gg=cc.createRadialGradient(W*.5,H*.38,0,W*.5,H*.38,Math.hypot(W*.5,H*.62)*.4);gg.addColorStop(0,"rgba(150,10,20,.45)");gg.addColorStop(1,"rgba(150,10,20,0)");cc.fillStyle=gg;cc.fillRect(0,0,W,H);
    var diag=Math.hypot(Math.max(ox,W-ox),Math.max(oy,H-oy)),D=2900,N=240,bats=[],start=null,last=0,opened=false;
    for(var i=0;i<N;i++){bats.push({t0:Math.random()*900,x:ox,y:oy,px:ox,py:oy,a:Math.random()*6.283,v:300+Math.random()*700,w:(Math.random()-.5)*2.4,s0:4+Math.random()*5,ph:Math.random()*6.28,fr:14+Math.random()*10});}
    function bat(x,y,s,rot,fl){
      bc.save();bc.translate(x,y);bc.rotate(rot);
      bc.beginPath();bc.moveTo(-1,0);
      bc.lineTo(-.5*s,-.35*s-.35*s*fl);bc.lineTo(-1.25*s,-.7*s*fl);bc.lineTo(-1*s,-.7*s*fl+.35*s);bc.lineTo(-.75*s,.05*s);bc.lineTo(-.5*s,.35*s);bc.lineTo(-.2*s,.1*s);bc.lineTo(0,.4*s);
      bc.lineTo(.2*s,.1*s);bc.lineTo(.5*s,.35*s);bc.lineTo(.75*s,.05*s);bc.lineTo(1*s,-.7*s*fl+.35*s);bc.lineTo(1.25*s,-.7*s*fl);bc.lineTo(.5*s,-.35*s-.35*s*fl);bc.lineTo(1,0);
      bc.closePath();bc.fill();bc.stroke();
      bc.beginPath();bc.ellipse(0,0,.17*s,.4*s,0,0,6.283);bc.fill();
      bc.beginPath();bc.moveTo(-.15*s,-.3*s);bc.lineTo(-.2*s,-.6*s);bc.lineTo(-.02*s,-.35*s);bc.moveTo(.15*s,-.3*s);bc.lineTo(.2*s,-.6*s);bc.lineTo(.02*s,-.35*s);bc.fill();
      bc.restore();
    }
    function frame(ts){
      if(start===null){start=ts;last=ts;}
      var el=ts-start,dt=Math.min(.05,(ts-last)/1000);last=ts;
      var p=Math.min(1,el/(D*.82)),R=diag*1.08*Math.pow(p,1.5);
      cc.globalCompositeOperation="destination-out";
      if(R>2){var g=cc.createRadialGradient(ox,oy,R*.7,ox,oy,R);g.addColorStop(0,"rgba(0,0,0,1)");g.addColorStop(1,"rgba(0,0,0,0)");cc.fillStyle=g;cc.beginPath();cc.arc(ox,oy,R,0,6.283);cc.fill();}
      bc.clearRect(0,0,W,H);bc.fillStyle="#050005";bc.strokeStyle="rgba(255,42,42,.65)";bc.lineWidth=1;
      cc.strokeStyle="#000";cc.lineCap="round";
      for(var i=0;i<bats.length;i++){
        var b=bats[i],age=el-b.t0;if(age<0)continue;
        var sec=age/1000;b.a+=b.w*dt;b.v*=1+.3*dt;b.px=b.x;b.py=b.y;
        b.x+=Math.cos(b.a)*b.v*dt;b.y+=Math.sin(b.a)*b.v*dt;
        var s=b.s0*(1+3.2*Math.pow(Math.min(sec/1.8,1),1.2));
        cc.lineWidth=s*2.6;cc.beginPath();cc.moveTo(b.px,b.py);cc.lineTo(b.x,b.y);cc.stroke();
        if(b.x<-80||b.x>W+80||b.y<-80||b.y>H+80)continue;
        bat(b.x,b.y,s,b.a+1.5708,Math.sin(sec*b.fr+b.ph));
      }
      if(!opened&&el>1300){opened=true;open();}
      if(el<D+200){requestAnimationFrame(frame);}
      else{cv[0].style.transition="opacity .3s";cv[0].style.opacity="0";setTimeout(function(){cv[0].remove();bv[0].remove();},400);}
    }
    requestAnimationFrame(frame);
    setTimeout(function(){if(!opened){opened=true;open();}},2200);
  });
})();
