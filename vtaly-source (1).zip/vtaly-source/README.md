# vtaly bio page

A single-page vampire bio site built with plain HTML, CSS and vanilla JavaScript.
No framework and no runtime dependencies. Node is only used for the dev server and the build.

## Quick start
```bash
npm run dev      # http://localhost:5173 (serves src/, supports audio/video seeking)
npm run build    # writes dist/ and dist/index.single.html (everything inlined, ~3 MB)
npm run format   # Prettier (run `npm install` once first)
npm run lint     # ESLint starter config
```
`npm run dev` and `npm run build` need no `npm install`.

## Layout
```
src/
  index.html          semantic markup, loads CSS and JS in order
  css/01..16-*.css    cascade-ordered layers (load order matters)
  js/00..32-*.js      one file per feature, classic deferred scripts
  assets/             song.mp3, bg.mp4
scripts/              build.mjs, dev.mjs
tools/                make_city_video.py (generates assets/bg.mp4)
vercel.json           build command, cache and security headers
```

## Conventions
- **State:** shared values live on `window.VT` (`level`, `busy`, `gain`, `muted`) in `js/00-state.js`.
- **Events:** the entry gate dispatches `vtopen` on `document` once the bat swarm has revealed the page.
  Effects that should wait for the reveal listen for it.
- **More events:** `vtbite` and `vtstrike` (detail `{x, y}`) fire when the fangs land and when lightning hits the name.
  `19-impact-fx.js` listens for them (screen shake, glass cracks).
- **Entrance:** `17-entrance.js` adds `body.pre-open` at load and swaps it for `body.opening` on `vtopen`,
  so each card section eases in with a staggered delay (`11-entrance-transitions.css`).
- **Command events:** `vtsummon` (lightning), `vtstorm` (bat storm) and `vtstormstart` are fired by the palette, keys
  and secret word; `22-sfx.js` turns `vtstrike`, `vtbite` and `vtstormstart` into synthesized sounds (Web Audio, no files).
- **After Effects style layer:** `25-ae-fx.js` exposes `VT.flare`, `VT.sparks`, `VT.aberrate`, `VT.slices`, `VT.zoom`, `VT.punch`
  and fires them on `vtbite`, `vtstrike`, `vtstormstart`, `vttitlehit` and strong beats. `26-ae-title-sequence.js` plays a
  letterboxed kinetic title card after the reveal (`vttitle` triggers the riser sound, `vttitlehit` the flare).
- **Strike transitions:** `32-strike-transitions.js` plays one of eight transitions on every `vtstrike` (cube turn horizontal,
  cube turn vertical, push, wipe, split shutters, blinds, iris, flash). They are shuffled so none repeats until all have
  played, and the wipe picks a random direction. All share one easing language and avoid blur pops, hue shifts and
  mirrored text. The CSS is `16-strike-transitions.css` (`html.tx-<id>` animates `<main>`, overlays are created by JS).
  The palette command "Play a page transition" previews the next one.
- **Quality:** `27-quality.js` sets `VT.quality` (`high` or `low`, saved in localStorage). `Q` or the palette toggles it, and a
  frame-rate governor switches to `low` after three slow 2-second windows. `low` hides grain, scanlines, light leaks, spotlight,
  the big record backdrop and embers (CSS), and skips aberration, slices, zoom, spectrum and rain (JS).
- **Spectrum:** `13-audio-reactive.js` publishes `VT.analyser`; `31-spectrum.js` draws the bottom-of-screen spectrum from it.
- **Motion:** every animated feature checks `prefers-reduced-motion` and falls back to a static state.
- **Load order:** scripts are `defer`red and run in numeric order, so a file may rely on the ones before it.

## Easy edits
- Name: `data-t="vtaly"` and the text in `<span id="nm">` (`src/index.html`); the fonts the bite cycles through are in `10-bite-fangs.js`.
- Bio words: the `<b class="pt">` elements. Badges: the `.badges` block (`data-tip` is the tooltip).
- Links: NameMC URL and Discord username in `index.html` and `04-discord-copy.js`.
- Background video: `python3 tools/make_city_video.py` (needs numpy, pillow, ffmpeg), then move `city.mp4` to `src/assets/bg.mp4`.

## Deploy
Vercel: import the repo. `vercel.json` already sets the build command and output directory.
Any static host: upload `dist/` (or just `dist/index.single.html`).

## Effects at a glance
Bat-swarm reveal, staggered entrance, 3D banner, lightning that recolors the name, fangs that bite and swap the font
(with screen shake and glass cracks), cursor spotlight, eyes that follow the pointer, click bat bursts,
name scramble on hover, paint vampire, audio-reactive glow, vinyl player,
synthesized thunder / bite / bat sounds, full-screen bat storm, command palette, glitching entry title,
cinematic title sequence, lens flares, chromatic aberration, datamosh slices, radial zoom bursts, camera punch, light leaks, CRT scanlines,
audio spectrum, rain, pet bat, magnetic badges and buttons, effects-quality governor.

## Keyboard shortcuts
`B` bite, `P` paint, `S` bat storm, `Q` effects quality, `/` command palette, `M` mute. The progress bar is clickable.
Secret: type `dracula`.

## Honest limitations
- The CSS is split into cascade-ordered layers, not yet consolidated: later files override earlier ones.
- JS files are classic scripts sharing `window.VT`, not ES modules. There are no automated tests.
- Next steps if this grows: merge the CSS layers, convert to ES modules with a small event bus, add Playwright smoke tests.
- You must have the right to use `assets/song.mp3` publicly.
